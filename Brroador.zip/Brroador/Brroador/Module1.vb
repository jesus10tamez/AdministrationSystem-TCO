﻿Imports System.Data
Imports System.Data.OleDb
Module Module1
    Public conexion As New OleDbConnection
    Public estado As String
    Public comand As New OleDbCommand

    Sub enlace()
        Try
            conexion.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\jesus\OneDrive\Escritorio\base\proyecto tallerPOO.accdb"
            conexion.Open()
            estado = "conectado"
        Catch ex As Exception
            estado = "desconectado"

        End Try
    End Sub

End Module
